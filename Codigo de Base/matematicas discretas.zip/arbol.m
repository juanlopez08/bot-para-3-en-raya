classdef arbol < handle

    properties
        raiz;
       
    end
    
    methods
       
        function obj = arbol()
            obj.raiz = nodo(zeros(3,3));  %la matriz o mesa de ceros
        end
        
        function raiz = getRaiz(arbol)
            raiz = arbol.raiz;         
        end
        
        function crearRaiz(obj, board)
            obj.raiz = nodo(board);
            obj.raiz.rama = nodo([]);
        end
        
        function crearArbolNivel1(obj, board)
            contador = 1;
            for i=1:3
                for j=1:3
                    board2 = board;
                    if(board(i,j)==0)
                        board2(i,j) = 1;
                        obj.raiz.rama(contador) = nodo(board2);
                        obj.raiz.rama(contador).rama = nodo([]);
                        contador = contador + 1;
                    end
                end
            end
        end
        
        function crearArbolNivel2(obj, board, ind)
            contador = 1;
            for i=1:3
                for j=1:3
                    board2 = board;
                    if(board(i,j)==0)
                        board2(i,j) = 2;
                        obj.raiz.rama(ind).rama(contador) = nodo(board2);
                        contador = contador + 1;
                    end
                end
            end
        end
        
        function [row, col] = MejorJugada(arbol, avalaiblePositions)
            fd = 0;
            jugadaMinim = zeros(3,3);
            jugadaMaxim = zeros(3,3);
            min = 111;
            max = -111;
            MAX = 0;
            MIN = 0;          
            
            
            board = arbol.raiz.contenido;
            
                 if((board(2,2)==2 && board(1,1)==1) && board(3,3)==2 && board(1,2)==0 && board(1,3)==0 && board(2,1)==0 && board(2,3)==0 && board(3,2)==0)
                       row=3;
                       col=1;
                       return
                 end 
             
                  
            
            for i=1:numel(arbol.raiz.rama)
          %      Ocupar el centro de ser posible
                for m=1:numel(avalaiblePositions)
                   if(avalaiblePositions(m)==5)
                      row = 2;
                      col = 2;
                      return
                   end
                end
                
           %     ocupa la ultima posicion de la mesa
                if(numel(avalaiblePositions) == 1)
                    for m=1:3
                        for n=1:3
                            if(arbol.raiz.contenido(m,n)==0)
                                row = m;
                                col = n;
                                return
                            end
                        end
                    end
                end
                
                 %MINIMAX
                for j=1:numel(arbol.raiz.rama(i).rama)
                    jugadaMinim = arbol.raiz.rama(i).rama(j).contenido;
                    for k=1:3
                       %Se calcula el numero de filas y columnas que MIN
                       %puede llegar a ocupar para ganar
                       %---------------
                       % en filas
                       if((jugadaMinim(k,1)==2||jugadaMinim(k,1)==0) && (jugadaMinim(k,2)==2||jugadaMinim(k,2)==0) && (jugadaMinim(k,3)==2||jugadaMinim(k,3)==0))
                           MIN = MIN + 1;
                           
                       end
  
                       if((jugadaMinim(1,k)==2||jugadaMinim(1,k)==0) && (jugadaMinim(2,k)==2||jugadaMinim(2,k)==0) && (jugadaMinim(3,k)==2||jugadaMinim(3,k)==0))
                           MIN = MIN + 1;
                           
                       end
                       %Se calcula el numero de filas y columnas que MAX
                       %puede llegar a ocupar para ganar
                       %-----------------
                       %en columnas
                       if((jugadaMinim(k,1)==1||jugadaMinim(k,1)==0) && (jugadaMinim(k,2)==1||jugadaMinim(k,2)==0) && (jugadaMinim(k,3)==1||jugadaMinim(k,3)==0))
                           MAX = MAX + 1;
                           
                       end
                       if((jugadaMinim(1,k)==1||jugadaMinim(1,k)==0) && (jugadaMinim(2,k)==1||jugadaMinim(2,k)==0) && (jugadaMinim(3,k)==1||jugadaMinim(3,k)==0))
                           MAX = MAX + 1;
                          
                       end
                       if(jugadaMinim(k,1)==1 && jugadaMinim(k,2)==1 && jugadaMinim(k,3)==1)
                           MAX = MAX + 111;
                           
                       end
                       if(jugadaMinim(1,k)==1 && jugadaMinim(2,k)==1 && jugadaMinim(3,k)==1)
                           MAX = MAX + 111;
                          
                       end
                    end
                       %si MIN puede llegar ocupar las diagonales (calculada por minimax)
                       if((jugadaMinim(1,1)==2||jugadaMinim(1,1)==0) && (jugadaMinim(2,2)==2||jugadaMinim(2,2)==0) && (jugadaMinim(3,3)==2||jugadaMinim(3,3)==0))
                           MIN = MIN + 1;
                       end
                       if((jugadaMinim(1,3)==2||jugadaMinim(1,3)==0) && (jugadaMinim(2,2)==2||jugadaMinim(2,2)==0) && (jugadaMinim(3,1)==2||jugadaMinim(3,1)==0))
                           MIN = MIN + 1;
                       end
                       %si MAX puede llegar ocupar las diagonales (calculada por minimax)
                       if((jugadaMinim(1,1)==1||jugadaMinim(1,1)==0) && (jugadaMinim(2,2)==1||jugadaMinim(2,2)==0) && (jugadaMinim(3,3)==1||jugadaMinim(3,3)==0))
                           MAX = MAX + 1;
                       end
                       if((jugadaMinim(1,3)==1||jugadaMinim(1,3)==0) && (jugadaMinim(2,2)==1||jugadaMinim(2,2)==0) && (jugadaMinim(3,1)==1||jugadaMinim(3,1)==0))
                           MAX = MAX + 1;
                       end
                       if(jugadaMinim(1,1)==1 && jugadaMinim(2,2)==1 && jugadaMinim(3,3)==1)
                           MAX = MAX + 111;
                       end
                       if(jugadaMinim(1,3)==1 && jugadaMinim(2,2)==1 && jugadaMinim(3,1)==1)
                           MAX = MAX + 111;
                       end
                       fd = MAX - MIN;
                       arbol.raiz.rama(i).rama(j).setValor(fd);
                       fd = 0;
                       MAX = 0;
                       MIN = 0;
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%
               
                 
              %  SI MINIMAX DEVUELVE DOS VALORES DE HOJAS IGUALES ENTRA A
              %  VALIDAR 
%               SI HAY DOS EN FILA Y ELIGE LA MEJOR
               for k=1:3
                if((board(k,1)==0 && board(k,2)==1) &&  board(k,3)==1 )
                   row = k;
                   col = 1;
                   return
                   end
               end
                for k=1:3
                 if((board(k,1)==0 && board(k,2)==2) &&  board(k,3)==2 )
                   row = k;
                   col = 1;
                   return
                   end
                end
                for k=1:3
                 if((board(k,1)==1 && board(k,2)==0) &&  board(k,3)==1 )
                   row = k;
                   col = 2;
                   return
                   end
                end
               for k=1:3
                 if((board(k,1)==2 && board(k,2)==0) &&  board(k,3)==2 )
                   row = k;
                   col = 2;
                   return
                   end
                end
                
                for k=1:3
                 if((board(k,1)==1 && board(k,2)==1) &&  board(k,3)==0 )
                   row = k;
                   col = 3;
                   return
                   end
                end
                for k=1:3
                 if((board(k,1)==2 && board(k,2)==2) &&  board(k,3)==0 )
                   row = k;
                   col = 3;
                   return
                   end
                end
                
              %  SI MINIMAX DEVUELVE DOS VALORES DE HOJAS IGUALES ENTRA A
              %  VALIDAR 
              %  SI HAY DOS EN COLUMNA Y ELIGE LA MEJOR

              if((board(1,3)==2 && board(2,2)==1) && board(3,1)==2 && board(1,1)==0 && board(2,1)==0 && board(2,1)==0 && board(2,3)==0 && board(3,3)==0)
                  row=3;
                  col=2;
                  return
              end 
              
              for k=1:3
                 if((board(1,k)==0 && board(2,k)==1) &&  board(3,k)==1 )
                   row = 1;
                   col = k;
                   return
                   end
              end
                
              for k=1:3
                 if((board(1,k)==0 && board(2,k)==2) &&  board(3,k)==2 )
                   row = 1;
                   col = k;
                   return
                   end
              end
                for k=1:3
                 if((board(1,k)==1 && board(2,k)==0) &&  board(3,k)==1 )
                   row = 2;
                   col = k;
                   return
                   end
                end
                for k=1:3
                 if((board(1,k)==2 && board(2,k)==0) &&  board(3,k)==2 )
                   row = 2;
                   col = k;
                   return
                   end
                end
               for k=1:3
                 if((board(1,k)==1 && board(2,k)==1) &&  board(3,k)==0 )
                   row = 3;
                   col = k;
                   return
                   end
               end
                 for k=1:3
                 if((board(1,k)==2 && board(2,k)==2) &&  board(3,k)==0 )
                   row = 3;
                   col = k;
                   return
                   end
                end
              
           % validar diagonal principal
            if((board(1,1)==1 && board(2,2)==1 && board(3,3)==0))
                row = 3;
                col = 3;
                return
            end
             if((board(1,1)==2 && board(2,2)==2 && board(3,3)==0))
                row = 3;
                col = 3;
                return
             end
            if((board(1,1)==1 && board(2,2)==0 && board(3,3)==1))
                row = 2;
                col = 2;
                return
            end
            if((board(1,1)==2 && board(2,2)==0 && board(3,3)==2))
                row = 2;
                col = 2;
                return
            end
            if((board(1,1)==0 && board(2,2)==1 && board(3,3)==1))
                row = 1;
                col = 1;
                return
            end
            if((board(1,1)==0 && board(2,2)==2 && board(3,3)==2))
                row = 1;
                col = 1;
                return
            end
        
            %validar diagonal secundaria
            if((board(1,3)==1 && board(2,2)==1 && board(3,1)==0))
                row = 3;
                col = 1;
                return
            end
             if((board(1,3)==2 && board(2,2)==2 && board(3,1)==0))
                row = 3;
                col = 1;
                return
             end
             if((board(1,3)==1 && board(2,2)==0 && board(3,1)==1))
                row = 2;
                col = 2;
                return
            end
            if((board(1,3)==2 && board(2,2)==0 && board(3,1)==2))
                row = 2;
                col = 2;
                return
            end
            if((board(1,3)==0 && board(2,2)==1 && board(3,1)==1))
                row = 1;
                col = 3;
                return
            end
             if((board(1,3)==0 && board(2,2)==2 && board(3,1)==2))
                row = 1;
                col = 3;
                return
            end
                
                %%%%%%%%%%%%%%%%%%%%%%%% FIN VALIDACION SECUNDARIA
                
                
                for m=1:numel(arbol.raiz.rama(i).rama)
                    if(arbol.raiz.rama(i).rama(m).getValor < min)
                        min = arbol.raiz.rama(i).rama(m).getValor;
                    end
                end
                arbol.raiz.rama(i).setValor(min);
        end
            
            for i=1:numel(arbol.raiz.rama)
                if(arbol.raiz.rama(i).getValor >= max)
                    max = arbol.raiz.rama(i).getValor;
                    jugadaMaxim = arbol.raiz.rama(i).contenido;               
                end
            end
            
            arbol.raiz.setValor(max);
            
            for i=1:3
                for j=1:3
                    if(arbol.raiz.contenido(i,j) ~= jugadaMaxim(i,j))
                        row = i;
                        col = j;
                        return
                    end
                end
            end
        end  
    end
end
